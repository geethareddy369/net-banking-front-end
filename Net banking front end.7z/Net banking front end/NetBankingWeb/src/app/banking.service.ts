import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankingService {
  
  myMethod$: Observable<any>;
  private myMethodSubject = new Subject<any>();

  
  constructor(private http: HttpClient) {
   
   }


  getAccountSummary(username) {

    return this.http.get("http://localhost:9876/banking/getAccountSummary",{params:{username:username}});

  }
  validateLogin(username,password){
    return this.http.get("http://localhost:9876/banking/validateuser",{params:{username:username,password:password}});
  }

  transactionHistory(username){
    return this.http.get("http://localhost:9876/banking/transactions",{params:{username:username}});
  }
  
balanceCheck(username){
  return this.http.get("http://localhost:9876/atm/balance",{params:{id:username}})
}

}
