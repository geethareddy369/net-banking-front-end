import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankingService } from './banking.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  AccountDetails: any[] = [];
  username:any;
  balance:any
 /*  account: Object; */
  constructor(private router:Router, private service: BankingService) { }
  onAccountSummary(){
    this.router.navigate(['./accountSummary']);
  
  }
  onTransactionHistory(){
    this.router.navigate(['./transactionHistory']);
  }
  onProfile(){
    this.router.navigate(['./profile']);

  }
  onLogout(){
    this.router.navigate(['./logout']);
  }

  ngOnInit() {
    this.username=localStorage.getItem("username")
this.service.getAccountSummary(this.username).subscribe((data: any) =>{

this.AccountDetails = data
}
); 

this.service.balanceCheck(this.username).subscribe((data:any)=>this.balance=data)
   }

}
