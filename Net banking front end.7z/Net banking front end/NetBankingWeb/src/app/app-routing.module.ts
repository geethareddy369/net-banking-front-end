import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
import { DashboardComponent } from './dashboard.component';
import { AccountSummaryComponent } from './account-summary.component';
import { TransactionHistoryComponent } from './transaction-history.component';
import { ProfileComponent } from './profile.component';
import { LogoutComponent } from './logout.component';


const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'accountSummary',component:AccountSummaryComponent},
  {path:'transactionHistory',component:TransactionHistoryComponent},
  {path:'profile',component:ProfileComponent},
  {path:'logout',component:LogoutComponent},
  {path:'',redirectTo:'/login',pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
