import { Component, OnInit } from '@angular/core';
import { BankingService } from './banking.service';

@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.css']
})
export class TransactionHistoryComponent implements OnInit {
  AccountDetails: any[] = [];
  
  username:any;
  constructor(private service:BankingService) { }

  ngOnInit() {

    this.username=localStorage.getItem("username")
this.service.transactionHistory(this.username).subscribe((data: any) =>{

this.AccountDetails = data
console.log(data)
console.log(this.AccountDetails)}
); 
    

  }

}
