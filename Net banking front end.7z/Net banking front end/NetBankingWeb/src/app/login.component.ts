import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankingService } from './banking.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  model:any={};

 result:boolean;
  public constructor(private router:Router, private service:BankingService) {
    
   }

  ngOnInit() {
  }


  onLogin(){
localStorage.setItem("username",this.model.username)
 console.log(this.model.username)
 this.service.validateLogin(this.model.username,this.model.password).subscribe((data:boolean)=>{this.result=data
  if(this.result){
    alert("login success")
    this.router.navigate(['/dashboard']);
  }
  else
  alert("Invalid username or password")
});



  }
}
