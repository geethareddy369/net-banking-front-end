import { Component, OnInit } from '@angular/core';
import { BankingService } from './banking.service';



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  AccountDetails: any[] = [];
  
username:any;
  constructor(private service:BankingService) {
   
  
   }

  ngOnInit() {

    this.username=localStorage.getItem("username")
this.service.getAccountSummary(this.username).subscribe((data: any) =>{

this.AccountDetails = data
console.log(data)
console.log(this.AccountDetails)}
); 
    
  }


}
