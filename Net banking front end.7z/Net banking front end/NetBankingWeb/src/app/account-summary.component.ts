import { Component, OnInit } from '@angular/core';
import { BankingService } from './banking.service';

@Component({
  selector: 'app-account-summary',
  templateUrl: './account-summary.component.html',
  styleUrls: ['./account-summary.component.css']
})
export class AccountSummaryComponent implements OnInit {
  AccountDetails: any[] = [];

 balance:any
username:any;
  constructor(private service: BankingService) { }

  ngOnInit() {
    this.username=localStorage.getItem("username")
    this.service.getAccountSummary(this.username).subscribe((data: any) => this.AccountDetails = data);  
    this.service.balanceCheck(this.username).subscribe((data:any)=>this.balance=data)
  }

}
